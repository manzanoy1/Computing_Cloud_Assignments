<!DOCTYPE html>
<html>
	<head>
		<title>Assignment 4</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			print "$h1 Assignment 4 $h1End";
			
			$divClass = 'exercise'; # one of the classes defined in CSS file, myStyle.css inside css folder.
			
			$tr = '<tr>'; # store <tr> tag inside $tr variable. <tr> indicates start of row in a table.
			$trEnd = '</tr>'; # store </tr> tag inside $trEnd variable. </tr> indicates end of a row in a table.
			
			$th = '<th>'; # table header
			$thEnd = '</th>'; # end of table header
			
			$td = "<td>"; # store <td> tag inside $td variable. <td> indicates start of a cell in a table.
			$tdEnd = "</td>"; # store </td> tag inside $tdEnd variable. </td> indicates end of a cell in a table.
			
			$table = "<table>"; # store <table> tag inside $table variable. <table> indicates start of a table in an HTML page.
			$tableEnd = "</table>"; # store </table> tag inside $tableEnd variable. </table> indicates end of a table in an HTML page.
			
			$div = "<div class=$divClass>"; # <div class='exercise'> indicates start of a new section that falls under 'exercise' class (CSS).
			$divEnd = "</div>"; # </div> indicates end of the section.
			
			$p = "<p>"; # <p> indicates start of a paragraph in an HTML page.
			$pEnd = "</p>"; # </p> indicates end of a paragraph in an HTML page.
			
			$lineBreak = '<br>'; # line break in HTML page.
			$lessThan = '&lt;'; # '<' symbol
			$greaterThan = '&gt;'; # '>' symbol
			
		?>
					
		<?php
		
			# Modify the code below to represent grading scheme for this course (A, A-, B+, B, B-, ...).
			$score = mt_rand(0, 100); # randomly generate integer between 0 and 100.

			print $div;
				print "$p Problem 1: Modify existing code to represent grading scheme for this course (A, A-, B+, B, B-, ...) (30 Points) $pEnd";
				print "$p Your Score is $score out of 100. $pEnd";
				if($score >= 93){
					print "$p Your letter grade is A. $pEnd";
				}else if($score >= 90){
					print "$p Your letter grade is A-. $pEnd";
				}elseif($score >= 87){
					print "$p Your letter grade is B+. $pEnd";
				}elseif($score >= 84){
					print "$p Your letter grade is B. $pEnd";
				}elseif($score >= 80){
					print "$p Your letter grade is B-. $pEnd";
				}elseif($score >= 77){
					print "$p Your letter grade is C+. $pEnd";
				}elseif($score >= 74){
					print "$p Your letter grade is C. $pEnd";
				}elseif($score >= 70){
					print "$p Your letter grade is C-. $pEnd";
				}elseif($score >= 67){
					print "$p Your letter grade is D+. $pEnd";
				}else if($score >= 63){
					print "$p Your letter grade is D. $pEnd";
				}else if($score >= 60){
					print "$p Your letter grade is D-. $pEnd";
				}else{
					print "$p Your letter grade is F. $pEnd";
				}
				
			print $divEnd;
			
			# create another section
			print $div;
				print "$p Example 1: Printing a table using nested for loops. $pEnd";
				$numRows = 5;
				$numColumns = 7;
				print $table;
					for($i = 0; $i < $numRows; $i++){
						print $tr; // Start of a row
						for($j = 0; $j < $numRows; $j++){
							// print columns
							print "$td Row: $i, Col: $j $tdEnd";
						}
						print $trEnd; // end of a row
					}
				print $tableEnd;
				print "$p Problem 2: What happens if you assign value 5 to $numRows and 
				        value 7 to $numColumns variable at line 65 and 66? (10 Points) -It adds more rows and columns. The row will count how many rows is in each column. 
					  $pEnd";
			print $divEnd;
					
			
			$cloud = '&#9729;'; # unicode to display cloud symbol in HTML
			$sun = '&#9728;'; # unicode to display sun symbol in HTML
			$umbrella = '&#9730;'; # unicode to display umbrella symbol in html
			
			print $div;
				print "$p Problem 3: Create another table in this section that looks exactly like the one shown in the document attached herewith.
						  Use a nested for loops as shown above to get similar output as the one shown in the document. (30 Points).
					   $pEnd";
				
				# Your code starts here for Problem 3.
				$numRows = 4;
				$numColumns = 7;
				print $table;
					for($i = 0; $i < $numRows; $i++){
						print $tr; // Start of a row
						for($j = 0; $j < $numRows; $j++){
							print "$td $sun $tdEnd $td $cloud $tdEnd";
						}
						print $trEnd; // end of a row
					}
				print $tableEnd;
				
			print $divEnd;
			
			print $div;
				print "$p
						1. There should be no errors in your code (10 Points). $lineBreak
						2. You should provide a public link to your website 
					and I should be able to access it (10 Points). $lineBreak
						3. Upload index.php and a snapshot of your page (10 Points). $lineBreak
					$pEnd
				";
			print $divEnd;
		?>
	</body>
</html>
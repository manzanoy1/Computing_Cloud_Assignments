<!DOCTYPE html>
<html>
	<head>
		<title>Assignment 5</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			$divClass = 'exercise'; # one of the classes defined in CSS file, myStyle.css inside css folder.
			
			$tr = '<tr>'; # store <tr> tag inside $tr variable. <tr> indicates start of row in a table.
			$trEnd = '</tr>'; # store </tr> tag inside $trEnd variable. </tr> indicates end of a row in a table.
			
			$th = '<th>'; # table header
			$thEnd = '</th>'; # end of table header
			
			$td = "<td>"; # store <td> tag inside $td variable. <td> indicates start of a cell in a table.
			$tdEnd = "</td>"; # store </td> tag inside $tdEnd variable. </td> indicates end of a cell in a table.
			
			$table = "<table>"; # store <table> tag inside $table variable. <table> indicates start of a table in an HTML page.
			$tableEnd = "</table>"; # store </table> tag inside $tableEnd variable. </table> indicates end of a table in an HTML page.
			
			$div = "<div class=$divClass>"; # <div class='exercise'> indicates start of a new section that falls under 'exercise' class (CSS).
			$divEnd = "</div>"; # </div> indicates end of the section.
			
			$p = "<p>"; # <p> indicates start of a paragraph in an HTML page.
			$pEnd = "</p>"; # </p> indicates end of a paragraph in an HTML page.
			
			$lineBreak = '<br>'; # line break in HTML page.
			$lessThan = '&lt;'; # '<' symbol
			$greaterThan = '&gt;'; # '>' symbol
			
			$ol = '<ol>';
			$olEnd = '</ol>';
			
			$ul = '<ul>';
			$ulEnd = '</ul>';
			
			$li = '<li>';
			$liEnd = '</li>';
			
			$b = '<b>';
			$bEnd = '</b>';
			
			$totalPoints = 0;
			
			$star = "&#10032;";
			
			print "$h1 Assignment 5 $h1End";
			
		?>
					
		<?php
				$listOfFruits = array('Apple', 'Banana', 'Avocado', 'Kiwi', 'Strawberries');
			
				printExamples(1, 'Printing fruits in an unordered HTML list using a for loop.');
				
				printProblemsToSolve(1, 'Did you see list of fruits printed in your webpage? 
									 Write your answer here ... - Yes, I can see it.', 5);
				printProblemsToSolve(2, 'Can you add at least three new fruits to the list $listOfFruits using 
									array_push(...)?', 15);
									
				array_push($listOfFruits, 'Coconut', 'Pear', 'Blueberry');
				
				foreach($listOfFruits as $item){
				print "$ul $item $ulEnd";
			}
				
				# Code for Problem 2 Starts Here ...
								
				# sorting the array
				sort($listOfFruits); # sorting array in ascending order
				printExamples(2, 'Sorting the array in ascending order and printing it in HTML list format.');
				
				printProblemsToSolve(3, 'Is your array of fruits sorted in ascending order? 
									     Did you notice your three fruits you just added in the list? 
									     Write your answer here ... -Yes, the array sorted the list in alphabetical order from top to bottom. I can also see my added fruits.', 5);
									 
				rsort($listOfFruits); # sorting array in descending order
				printExamples(3, 'Sorting the array in descending order and printing it in HTML list format.');
				
				printProblemsToSolve(4, 'Is your array of fruits sorted in descending order? 
									 Write your answer here ... -Yes, is in alphabetical order from bottom  ', 5);
									 
				printProblemsToSolve(5, "Locate and make changes to the function printItemLists(...)
									such that your output will highlight one of your favorite fruits with stars like this:
									$star Your Favorite Fruit $star (HTML code for the star symbol is stored in \$star variable): ", 20);
			
				sort($listOfFruits);
				printItemLists($listOfFruits);
				
				printProblemsToSolve(6, "Locate and make changes to function printTable() such that
										it will print a 4X4 table as shown in the sample webpage: ", 20);
				
				printTable();
				
			print $div;
				$totalPoints += 30;
				print "$ol
						$li There should be no errors in your code (10 Points). $liEnd
						$li You should provide a full functioning elastic beanstalk link (10 Points). $liEnd
						$li Upload zip file containing index.php and css folder. (10 Points). $liEnd
						$li Total Points: $b $totalPoints $bEnd $liEnd
					$olEnd
				";
			print $divEnd;
		?>
		
		<?php
			function printTable(){
				global $table, $tableEnd, $tr, $trEnd, $td, $tdEnd;
				# Your Code for Problem 6 Starts Here ...
				print $table;
					print "$tr
							$td (0, 0) $tdEnd
							$td (0, 1) $tdEnd
							$td (0, 2) $tdEnd
							$td (0, 3) $tdEnd
						$trEnd";
					
					print "$tr
							$td (1, 0) $tdEnd
							$td (1, 1) $tdEnd
							$td (1, 2) $tdEnd
							$td (1, 3) $tdEnd
						$trEnd";
						
					print "$tr
							$td (2, 0) $tdEnd
							$td (2, 1) $tdEnd
							$td (2, 2) $tdEnd
							$td (2, 3) $tdEnd
						$trEnd";
					
					print "$tr
							$td (3, 0) $tdEnd
							$td (3, 1) $tdEnd
							$td (3, 2) $tdEnd
							$td (3, 3) $tdEnd
						$trEnd";
				print $tableEnd;
			}
			
			function printItemLists($array){
				global $ul, $ulEnd, $li, $liEnd, $star;
				print $ul;
						foreach($array as $item){
							/* Your code for Problem 5 starts here. */
							if($item == 'Coconut'){ // modify here
								print "$star $item $star";
							}elseif($item == 'Pear'){
								print "$star $item $star";
							}elseif($item == 'Blueberry'){
								print "$star $item $star";
							}else{
								print "$li $item $liEnd";
							}
						
						}
				print $ulEnd;
			}
			
			function printExamples($example_num, $description){
				global $div, $divEnd, $p, $pEnd, $listOfFruits;
				print $div;
					print "$p Example $example_num: $description. $pEnd";
					printItemLists($listOfFruits);
				print $divEnd;
			}
			
			function printProblemsToSolve($problem_num, $problem_description, $points){
				global $div, $divEnd, $p, $pEnd, $totalPoints;
				print $div;
					print "$p Problem $problem_num: $problem_description ($points Points) $pEnd";
					$totalPoints += $points;
				print $divEnd;
			}
		?>
	</body>
</html>